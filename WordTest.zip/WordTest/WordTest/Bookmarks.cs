﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Word = Microsoft.Office.Interop.Word;

namespace WordTest
{
    class Bookmarks
    {
        static void BookmarksChange(Dictionary<string, string> data, Word.Document doc)
        {
            try
            {
                // Добавляем информацию
                // Bookmarks содержит все закладки
                int i = 0;
                foreach (Word.Bookmark mark in doc.Bookmarks)                
                    if(data.ContainsKey(mark.Name))                    
                        mark.Range.Text = data[mark.Name];                

                // Закрываем документ
                doc.Close();
                doc = null;
            }
            catch (Exception ex)
            {
                // Если произошла ошибка, то
                // закрываем документ и выводим информацию
                doc.Close();
                doc = null;
                Console.WriteLine("Во время выполнения произошла ошибка!");
                Console.ReadLine();
            }
        }
    }
}
